A Pen created at CodePen.io. You can find this one at https://codepen.io/My_Name_Ae_Jeff_v1/pen/WBYGaN.

 